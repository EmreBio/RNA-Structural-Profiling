For references and details for sample datasets, refer Manual.

Input the text files to SEQualyzer. Prefixes MacOS and Windows indicate which file to upload over Mac or Windows respectively. File name lists all data descriptions to choose for a file in SEQualyzer.

In case SEQualyzer fails to recognize the files, please check that the file paths in text input files are correct. You may have to give the complete address of your files in the text input. Remember to escape white spaces or special characters appropriately.